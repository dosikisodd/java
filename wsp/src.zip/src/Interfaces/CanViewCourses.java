package Interfaces;

public interface CanViewCourses {
    public void viewCourses();
}
