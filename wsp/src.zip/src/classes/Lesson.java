package classes;

public class Lesson {
	Course course;
	String lessonType;
	public Lesson(Course course, String lessonType) {
		this.course = course;
		this.lessonType = lessonType;
	}
}
