package enums;

public enum ManagerType {
    OFFICE_REGISTRATOR, DEPARTMENT
}