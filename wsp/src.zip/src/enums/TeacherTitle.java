package enums;

public enum TeacherTitle {
	PROFESSOR, LECTOR, SENIOR_LECTOR, TUTOR
}
