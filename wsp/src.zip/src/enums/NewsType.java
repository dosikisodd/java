package enums;

public enum NewsType {
	INFORMATION, WARNING
}
