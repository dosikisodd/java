package users;

public class Facultiy {

}
